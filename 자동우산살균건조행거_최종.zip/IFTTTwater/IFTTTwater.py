#! /usr/bin/python

# Imports
import spidev
import time
import requests

spi = spidev.SpiDev()
spi.open(0,0)
spi.max_speed_hz = 1350000

def analog_read(channel):
        r = spi.xfer2([1, (8+channel)<<4, 0])
        adc_out = ((r[1]&3)<<8)+r[2]
        return adc_out


# Water sensor
pinwater = 0

while True:
        time.sleep(0.1)
        # Read sensor value
        currentstate = analog_read(pinwater)
        # If the sensor is triggered
        if currentstate>=300:
                print("detected!")
                # Post IFTTT URL with event name, key
                r = requests.post('https://maker.ifttt.com/trigger/Full of water/with/key/bMkvO675to7YY45swbgdHu')
                time.sleep(900)
